//� A+ Computer Science
// www.apluscompsci.com

//number systems quiz 1A key  

import static java.lang.System.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import static java.lang.Integer.*;

public class NumberSystemsQuiz1AKEY
{

   public static void main( String args[] ) throws Exception
   {

		out.println("question 1\n\n");


	 	System.out.println(parseInt("0101",2));



		out.println("question 2\n\n");


	 	System.out.println(parseInt("1001",2));



		out.println("question 3\n\n");
		

	 	System.out.println(parseInt("10101101",2));



		out.println("question 4\n\n");


	 	System.out.println(parseInt("00010001",2));
	 	


		out.println("question 5\n\n");


	 	System.out.println(parseInt("01011000",2));



		out.println("question 6\n\n");


	 	System.out.println(parseInt("123",4));



		out.println("question 7\n\n");


	 	System.out.println(parseInt("111",3));



		out.println("question 8\n\n");



	 	System.out.println(parseInt("34",5));



		out.println("question 9\n\n");


	 	System.out.println(parseInt("256",8));
	 	


		out.println("question 10\n\n");



	 	System.out.println(parseInt("2134",6));
	 	
 	}
}

