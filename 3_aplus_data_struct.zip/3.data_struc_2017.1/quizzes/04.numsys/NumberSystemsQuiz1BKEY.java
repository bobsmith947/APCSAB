//� A+ Computer Science
// www.apluscompsci.com

//number systems quiz 1B key  

import static java.lang.System.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import static java.lang.Integer.*;

public class NumberSystemsQuiz1BKEY
{

   public static void main( String args[] ) throws Exception
   {

		out.println("question 1\n\n");


	 	System.out.println(parseInt("1111",2));



		out.println("question 2\n\n");


	 	System.out.println(parseInt("1101",2));



		out.println("question 3\n\n");
		

	 	System.out.println(parseInt("10101001",2));



		out.println("question 4\n\n");


	 	System.out.println(parseInt("00011001",2));
	 	


		out.println("question 5\n\n");


	 	System.out.println(parseInt("01011000",2));



		out.println("question 6\n\n");


	 	System.out.println(parseInt("123",4));



		out.println("question 7\n\n");


	 	System.out.println(parseInt("102",3));



		out.println("question 8\n\n");



	 	System.out.println(parseInt("142",5));



		out.println("question 9\n\n");


	 	System.out.println(parseInt("253",8));
	 	


		out.println("question 10\n\n");



	 	System.out.println(parseInt("2134",6));
	 	
 	}
}

