//� A+ Computer Science
// www.apluscompsci.com

//bitwise quiz key A   

import static java.lang.System.*;

import static java.lang.System.*;
import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;
import java.util.TreeMap;
import java.util.HashMap;

class BitwiseQuiz1KEYA
{
   public static void main(String args[])
   {
		int one = 6;
		out.println(0x2A);					//line 1 ______________


		out.println(3 & 5 );				//line 2 ______________


		out.println(21 | 7 );				//line 3 ______________


		out.println(14 ^ 19 );				//line 4 ______________


		out.println(one << 2 );				//line 5 ______________


		out.println(one | 3 & 7 );			//line 6 ______________


		out.println(4 ^ 15 | 2 );			//line 7 ______________


		out.println(9 ^ 7 & 3 );				//line 8 ______________


		out.println(one |= 11 );				//line 9 ______________


		out.println(one >> 2 );				//line 10 _____________


		out.println(one ^ 7 & 12 & 5 );		//line 11 _____________


   }
}

