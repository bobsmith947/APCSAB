//� A+ Computer Science  -  www.apluscompsci.com

//number systems worksheet 1 key   

import static java.lang.System.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import static java.lang.Integer.*;

public class NumberSystemsWorkSheet2KEY
{

   public static void main( String args[] ) throws Exception
   {

		out.println("question 1\n\n");


	 	System.out.println(Integer.toString(parseInt("324",5),8));



		out.println("question 2\n\n");


	 	System.out.println(Integer.toString(parseInt("A23",16),9));



		out.println("question 3\n\n");


	 	System.out.println(Integer.toString(parseInt("110010101001",2),16));



		out.println("question 4\n\n");


	 	System.out.println(Integer.toString(parseInt("651",7),3));
	 	


		out.println("question 5\n\n");


	 	System.out.println(Integer.toString(parseInt("19",11),6));



		out.println("question 6\n\n");


	 	System.out.println(Integer.toString(parseInt("7A2",15),11));



		out.println("question 7\n\n");


	 	System.out.println(Integer.toString(parseInt("1213",5),7));



		out.println("question 8\n\n");


	 	System.out.println(Integer.toString(parseInt("111010111001",2),13));



		out.println("question 9\n\n");


	 	System.out.println(Integer.toString(parseInt("3456",7),4));
	 	


		out.println("question 10\n\n");


	 	System.out.println(Integer.toString(parseInt("AE89",16),10));
	 	
 	}
}

