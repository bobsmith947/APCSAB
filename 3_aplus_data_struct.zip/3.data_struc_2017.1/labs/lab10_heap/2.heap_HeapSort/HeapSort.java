//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.util.List;
import java.util.ArrayList;
import static java.lang.System.*;

public class HeapSort
{
	private List<Integer> list;

	public HeapSort()
	{
		list = new ArrayList<Integer>();
	}

   public void swapUp(int index)
   {

	}

	public void swapDown(int index)
	{

	}

   public void heapSort(int[] nums)
   {

   }
   
   private void swap(int first, int last)
   {

  	}

	public String toString()
	{
		return list.toString();
	}
}