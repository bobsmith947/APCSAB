//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import static java.lang.System.*;

public class Number implements Comparable<Number>
{

	//add in instance variables
	
	//add in a constructor or two


	public int compareTo(Number param)
	{
		return 0;		
	}
	
	public String toString( )
	{
	  return "";
	}
}