//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.util.Scanner;
import static java.lang.System.*;

public class Convert
{
	private String sentence;
	private String binary;

	public Convert()
	{



	}

	public Convert(String sentence)
	{



	}

	public void convert()
	{











	}

	public String toString()
	{
		return "";
	}
}