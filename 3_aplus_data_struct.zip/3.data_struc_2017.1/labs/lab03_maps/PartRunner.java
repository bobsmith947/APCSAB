//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import static java.lang.System.*;

//Files needed
 	//Part.java
 	//PartList.java

public class PartRunner
{
	public static void main(String[] args)
	{
		PartList prog = new PartList("partinfo.dat");
		out.println(prog);
	}
}
