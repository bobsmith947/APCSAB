//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

//Files needed
 	//Part.java
 	//PartList.java

public class PartsRunner
{
	public static void main(String[] args)
	{
		PartList prog = new PartList("partinfo.dat");
		out.println(prog);
	}
}
