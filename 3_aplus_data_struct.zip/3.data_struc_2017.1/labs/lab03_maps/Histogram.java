//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.util.Map;
import java.util.TreeMap;
import java.util.Scanner;
import static java.lang.System.*;

public class Histogram
{
	private Map<String,Integer> histogram;

	public Histogram()
	{
	}

	public Histogram(String sent)
	{
	}
	
	public void setSentence()
	{
	}

	public String toString()
	{
		String output="";
		String allStars="";
		return output+"\n\n";
	}
}