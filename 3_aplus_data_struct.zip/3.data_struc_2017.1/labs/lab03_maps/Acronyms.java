//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import java.util.Scanner;
import static java.lang.System.*;

public class Acronyms
{
	private Map<String,String> acronymTable;

	public Acronyms()
	{



	}

	public void putEntry(String entry)
	{




	}

	public String convert(String sent)
	{
		Scanner chop = new Scanner(sent);
		String output ="";









		return output;
	}

	public String toString()
	{
		return "";
	}
}