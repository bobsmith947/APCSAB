//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

public class Part implements Comparable<Part>
{
	private String make, mode, rest;
	private int year;

	public Part(String line) 
	{
		String[] list = line.split(" ");




	}

	//have to have compareTo if implements Comparable
	public int compareTo( Part rhs )
	{





		return 0;
	}

	public String toString()
	{
		return "";
	}
}