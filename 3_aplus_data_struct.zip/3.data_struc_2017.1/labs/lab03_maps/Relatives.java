//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Scanner;
import static java.lang.System.*;

public class Relatives
{
	private Map<String,Set<String>> map;

	public Relatives()
	{



	}

	public void setPersonRelative(String line)
	{
		String[] personRelative = line.split(" ");










	}


	public String getRelatives(String person)
	{
		return "";
	}


	public String toString()
	{
		String output="";








		return output;
	}
}