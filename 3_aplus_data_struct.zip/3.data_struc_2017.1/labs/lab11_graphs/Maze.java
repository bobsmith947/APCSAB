//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.util.Scanner;
import static java.lang.System.*;

public class Maze
{
   private int[][] maze;

	public Maze()
	{
	}

	public Maze(int[][] m)
	{
	}

	public boolean checkForExitPath(int r, int c)
	{
		return false;
	}

	public String toString()
	{
		String output="";
		return output;
	}
}