//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import java.util.Set;
import java.util.TreeSet;
import java.util.Scanner;
import static java.lang.System.*;

public class BiDirectionalGraph
{
	private TreeMap<String, TreeSet<String>> map;
	private boolean yahOrNay;

	public BiDirectionalGraph(String line)
	{
	}

	public boolean contains(String name)
	{
		return true;
	}

	public void check(String first, String second, TreeSet<String> placedUsed)
	{
	}

	public String toString()
	{
		return "";
	}
}