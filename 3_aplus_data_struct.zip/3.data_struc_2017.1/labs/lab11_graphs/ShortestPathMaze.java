//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.util.Scanner;
import static java.lang.System.*;

public class ShortestPathMaze
{
   private int[][] maze;
   private int shortest;

	public ShortestPathMaze()
	{
	}

	public ShortestPathMaze(int[][] m)
	{
	}


	public void checkForExitPath(int r, int c, int path)
	{
	}
	
	public int getShortestPath()
	{
		return shortest;
	}

	public String toString()
	{
		String output="";
		return output;
	}
}