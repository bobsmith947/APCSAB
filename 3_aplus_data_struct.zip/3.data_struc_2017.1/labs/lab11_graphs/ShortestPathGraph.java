//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import java.util.Scanner;
import static java.lang.System.*;

public class ShortestPathGraph
{
	private TreeMap<String, String> map;
	private boolean yayOrNay;
	private int shortest;

	public ShortestPathGraph(String line)
	{
	}

	public boolean contains(String letter)
	{
		return true;
	}

	public void check(String first, String second, String placesUsed, int steps)
	{
	}

	public String toString()
	{
		return "";
	}
}