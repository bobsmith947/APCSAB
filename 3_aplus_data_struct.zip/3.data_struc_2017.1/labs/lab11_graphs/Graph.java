//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.util.Map;
import java.util.TreeMap;

public class Graph
{
	private TreeMap<String, String> map;
	private boolean yahOrNay;

	public Graph(String line)
	{
	}

	public boolean contains(String letter)
	{
	   return true;
	}

	public void check(String first, String second, String placesUsed)
	{
	}

	public String toString()
	{
		return "";
	}
}