//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

public class HistoTree
{
   private TreeNode root;

	public HistoTree( )
	{

	}

	public void addData(Comparable data)
	{





	}

	private TreeNode add(Comparable data, TreeNode tree)
	{






		return null;
	}

	private TreeNode search(Comparable data)
	{
		return null;
	}

	private TreeNode search(Comparable data, TreeNode tree)
	{






		return null;
	}

	public String toString()
	{
		return "";
	}

	private String toString(TreeNode tree)
	{
	
		return "";
	}
}