//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import static java.lang.System.*;

public class HistoTree
{
   private HistoNode root;

	public HistoTree( )
	{
		root = null;
	}

	public void addData(Comparable data)
	{
	}

	private HistoNode add(Comparable data, HistoNode tree)
	{
		return null;
	}

	public HistoNode search(Comparable data)
	{
		return null;
	}

	private HistoNode search(Comparable data, HistoNode tree)
	{
		return null;
	}

	public String toString()
	{
		return "";
	}

	private String toString(HistoNode tree)
	{
		return "";
	}
}