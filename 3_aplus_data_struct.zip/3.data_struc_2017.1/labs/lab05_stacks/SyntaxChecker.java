//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

import java.util.Stack;
import static java.lang.System.*;

public class SyntaxChecker
{
	private String exp;
	private Stack<Character> symbols;

	public SyntaxChecker()
	{
	}

	public SyntaxChecker(String s)
	{
	}
	
	public void setExpression(String s)
	{
	}

	public boolean checkExpression()
	{
		return false;
	}

	//write a toString
}