//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

public class PalinListRunner
{
	public static void main ( String[] args )
	{
		//add test cases			
	}
}