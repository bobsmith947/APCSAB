//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

public class PQTestRunner
{
	public static void main ( String[] args )
	{
		//add test cases		
	}
}