//(c) A+ Computer Science
//www.apluscompsci.com

//Name -  

import java.util.Queue;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.PriorityQueue;

public class PQTester
{
	private Queue<String> pQueue;

	public PQTester()
	{
	}

	public PQTester(String list)
	{
	}

	public void setPQ(String list)
	{
	}
	
	public Object getMin()
	{
		return "";
	}
	
	public String getNaturalOrder()
	{
		String output="";
		return output;		
	}

	//write a toString method
}