//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

public class Word
{
	private String theValue;
	
	//write a constructor method
	
	
	
	//write the getValue method
	
	
	
	//write the equals method
	
	
	
	//write the hashCode method
	
	
	
	//write the toString method

	
}