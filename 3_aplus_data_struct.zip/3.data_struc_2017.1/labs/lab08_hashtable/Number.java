//(c) A+ Computer Science
//www.apluscompsci.com

//Name -

public class Number
{
	private int theValue;
	
	public Number(int value)
	{


	}	
	
	public int getValue()
	{
		return theValue;
	}
	
	public boolean equals(Object obj)
	{
		return false;
	} 
	
	public int hashCode()
	{
		return 0;
	}

	public String toString()
	{
		return "";
	}	
}