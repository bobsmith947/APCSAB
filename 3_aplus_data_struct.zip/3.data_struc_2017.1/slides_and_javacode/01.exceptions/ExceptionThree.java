//(c) A+ Computer Science
// www.apluscompsci.com  

//exception example 3

public class ExceptionThree
{
	public static void main(String args[])
	{
		int num=32;
		if(num==32)
			throw new RuntimeException("num==32");
			//RunTimeException is not a checked Excpetion
	}
}
