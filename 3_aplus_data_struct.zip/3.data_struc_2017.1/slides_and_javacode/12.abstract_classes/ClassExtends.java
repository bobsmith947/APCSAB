//(c) A+ Computer Science
// www.apluscompsci.com

//inheritance example

import static java.lang.System.*;
import java.util.Scanner;

class A
{
	void fun()
	{
	}
}

class B
{
	void notFun()
	{
	}
}

class C
{
	void weird()
	{
	}
}

class D extends A,B   //no can do
{

}

public class ClassExtends
{
  public static void main ( String[] args )
  {
  }
}