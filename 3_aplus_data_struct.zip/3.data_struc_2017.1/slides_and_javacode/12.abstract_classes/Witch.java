//(c) A+ Computer Science
// www.apluscompsci.com

//abstract example three 

public class Witch extends Monster
{
  public Witch( String name )
  {
    super(name);
  }

  public String talk()
  {
     return "\"I like to fly on broom!\"\n\n";
  }
}