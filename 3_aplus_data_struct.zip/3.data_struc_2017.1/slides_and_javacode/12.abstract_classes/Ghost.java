//(c) A+ Computer Science
// www.apluscompsci.com

//Ghost example

class Ghost extends Monster
{
  public Ghost( String name )
  {
    super(name);
  }

  public String talk()
  {
     return "\"Where did I go?\"\n\n";
  }
}
