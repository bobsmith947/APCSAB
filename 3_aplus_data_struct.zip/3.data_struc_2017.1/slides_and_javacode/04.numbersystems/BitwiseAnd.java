//(c) A+ Computer Science
//www.apluscompsci.com 

//bitwise and example

import static java.lang.System.*;

public class BitwiseAnd
{
	public static void main(String args[])
	{
		int one=8;   //binary 1000
		int two=7;   //binary 0111
		out.println("8 & 7 == " + (one&two));
	}
}