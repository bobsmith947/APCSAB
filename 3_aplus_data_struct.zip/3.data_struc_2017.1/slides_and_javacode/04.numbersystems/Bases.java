//(c) A+ Computer Science
//www.apluscompsci.com

//base conversion example

import static java.lang.System.*;

public class Bases
{
	public static void main(String args[])
	{
		int x = 789;    //base 10
		int y = 043;    //base 8
		int z = 0x62;   //base 16

		out.println( "x  == " +  x  + "\n\n");
		out.println( "y  == " +  y  + '\n'+'\n');
		out.println( "z  == " +  z  + "\n\n");
	}
}