//(c) A+ Computer Science
//www.apluscompsci.com  

//bitwise shift left example

import static java.lang.System.*;

public class ShiftLeft
{
	public static void main(String args[])
	{
		int one=8;
		out.println("8 << 1 == " + (one<<1));
	}
}