//(c) A+ Computer Science
//www.apluscompsci.com 

//bitwise or example

import static java.lang.System.*;

public class BitwiseOr
{
	public static void main(String args[])
	{
		int one=8;   //binary 1000
		int two=7;   //binary 0111
		out.println("8 | 7 == " + (one|two));
	}
}