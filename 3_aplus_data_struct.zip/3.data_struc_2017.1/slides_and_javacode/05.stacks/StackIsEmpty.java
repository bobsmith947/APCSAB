//(c) A+ Computer Science
// www.apluscompsci.com  

//Stack example isEmpty

import static java.lang.System.*;
import java.util.Stack;

public class StackIsEmpty
{
	public static void main( String args[] )
	{
		//make a stack of integers named s
		
		//push 88, 23, 77, 22, and 11
		
		//use a while loop to print out each value in the stack		

	}
}