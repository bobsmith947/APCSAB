//(c) A+ Computer Science
//www.apluscompsci.com

//printing out a set with the new for loop  

import java.util.Set;
import java.util.TreeSet;

public class SetOutputNew
{
	public static void main(String args[])
	{
		Set<Double> vals = new TreeSet<Double>();
		vals.add(2.5);
		vals.add(5.8);
		vals.add(7.3);

		//add in a for each loop to print out all of the values in the set
		
		
		
	}
}